#include "myheader.h"

int main(int argc, char* argv[]) 
{
	int ls;
	char* string;
	int len = 0;
	int waitSize = 16;
	struct sockaddr_in serverAddr;
	struct sockaddr_in clientAddr;
	int clientAddrLen;
	int servPort;
	int n;
	int delay_ms;
	int bandwidth;

	if(argc != 4)
	{
		printf("Usage: echoServer <port(10000~30000)> <fixed delay(1~1000ms)> <bandwidth(1~1000Kbps)>\n");
		exit(1);
	}
	
	servPort = atoi(argv[1]);
	delay_ms = atoi(argv[2]);
	bandwidth = atoi(argv[3]);

	if(servPort < 10000 || servPort > 30000
		|| delay_ms < 1 || delay_ms > 1000
		|| bandwidth < 1 || bandwidth > 1000 ) 
	{
		printf("Usage: server <port(10000~30000)> <fixed delay(1~1000ms)> <bandwidth(1~1000Kbps)>\n");
		exit(1);
	}

	/* Create local (server) socket address */
	memset(&serverAddr, 0, sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);	// default IP addr
	serverAddr.sin_port = htons(servPort);


	/* Creat listen socket */
	if((ls = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
	{
		perror("Error: listen socket failed\n");
		exit(1);
	}

	/* Bind listen socket to the local socket address */
	if(bind(ls, (struct sockaddr *) &serverAddr, sizeof(serverAddr)) < 0) 
	{
		perror("Error: binding failed\n");
		exit(1);
	}

	myFrame rxData;
	struct timespec rxTime;
	struct timespec txTime;
	struct timespec sleepTime;
	double temp;
	while(1)
	{
		memset(&rxData, 0, sizeof(rxData));

		/* send Echo */
		clientAddrLen = sizeof(clientAddr);
		len = recvfrom(ls, (char*)&rxData, sizeof(myFrame), 0,
			(struct sockaddr*) &clientAddr, (socklen_t *) &clientAddrLen);
		printf("+ sent at: %u.%9u", rxData.txFwdTime.tv_sec, rxData.txFwdTime.tv_nsec);
		printf(" / seqno: %d / size: %d", rxData.seqno, rxData.dataByte);
 		printf(" / %s\n", rxData.string);

		clock_gettime(CLOCK_REALTIME, &rxTime);
		// debug: printf("now %u.%u\n", rxTime.tv_sec, rxTime.tv_nsec);


		// set Sleep time
		temp = delay_ms * 0.001;
		temp += (8.0*rxData.dataByte/bandwidth)/1.0E3;	// Kbps
		sleepTime.tv_sec = (int)temp;
		sleepTime.tv_nsec = (int)((temp - (int)temp)*1E9);
		printf("sleep for %lf second (%d ms + %d Bytes / %d Kbps)\n", \
				temp, delay_ms, rxData.dataByte, bandwidth);

		// debug: printf("%s\n",inet_ntoa(clientAddr.sin_addr));
		nanosleep(&sleepTime, NULL);

		clock_gettime(CLOCK_REALTIME, &txTime);
		// debug: printf("now %u.%09u\n", txTime.tv_sec, txTime.tv_nsec);
		rxData.txBwdTime.tv_sec = rxData.txFwdTime.tv_sec 
								+ (txTime.tv_sec - rxTime.tv_sec);
		rxData.txBwdTime.tv_nsec = rxData.txFwdTime.tv_nsec 
								+ (txTime.tv_nsec - rxTime.tv_nsec);
		if(rxData.txBwdTime.tv_nsec > 1E9) 
		{
			rxData.txBwdTime.tv_sec += 1;
			rxData.txBwdTime.tv_nsec -= (long int) 1E9;
		}

		// send back the echo message
		n = sendto(ls, (char*)&rxData, sizeof(myFrame), 0,
			(struct sockaddr *)&clientAddr, sizeof(clientAddr));
		if(n < 0) {
			perror("Error:\n");
			exit(1);
		}
		printf("- Echo at: %u.%09u", rxData.txBwdTime.tv_sec, rxData.txBwdTime.tv_nsec);
		printf(" / seqno: %d / size: %d", rxData.seqno, rxData.dataByte);
 		printf(" / %s\n", rxData.string);

	}

}
