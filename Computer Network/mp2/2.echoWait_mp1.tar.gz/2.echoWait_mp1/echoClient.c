#include "myheader.h"

int main(int argc, char* argv[]) 
{
	int s;
	char* servName;
	int servPort;
	char* string;
	int len = 0;
	struct sockaddr_in serverAddr;
	int n;
	int seqno = 0;
	int pktSize = 0;
	struct timespec txTime;
	struct timespec rxTime;

	myFrame txData;
	myFrame rxData;

	if(argc != 5)
	{
		printf("Usage: echoClient <server IP> <port> <pkt_size> <string>\n");
		exit(1);
	}

	servName = argv[1];
	servPort = atoi(argv[2]);
	pktSize = atoi(argv[3]);
	string = argv[4];

	/* Create remote (server) socket address */
	memset(&serverAddr, 0, sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	inet_pton(AF_INET, servName, &serverAddr.sin_addr);	// server IP addr
	serverAddr.sin_port = htons(servPort);

	/* Creat socket */
	if((s = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
	{
		perror("Error: socket creation failed\n");
		exit(1);
	}

	// Setting txData
	memset(&txData, 0, sizeof(txData));
	strncpy(txData.string, string, STRLEN);
	txData.seqno = seqno++;
	clock_gettime(CLOCK_REALTIME, &(txTime));
	txData.txFwdTime = txTime;
	//printf("%u.%09u (%d bytes)\n", txData.txFwdTime.tv_sec, \
						txData.txFwdTime.tv_nsec, sizeof(txData));
	txData.dataByte = pktSize;

	// send the echo message
	n = sendto(s, (char*)&txData, sizeof(txData), 0,
		(struct sockaddr *)&serverAddr, sizeof(serverAddr));
	printf("-- actual tx frame size: %d bytes\n",n);

	/**********************************************************
	 * here, the message has been sent, 
	 * it is delayed for duration of (data size / bandwdith), 
	 * and echoed back
	 **********************************************************/

	/* receive Echo */
	memset(&rxData, 0, sizeof(rxData));
	len = recvfrom(s, (char*)&rxData, sizeof(rxData), 0, NULL, NULL);
	clock_gettime(CLOCK_REALTIME, &(rxTime));

	printf("Echoed packet (%d) received: \n", rxData.seqno);
	printf("TX at %u.%09u\n", txTime.tv_sec, txTime.tv_nsec);
	printf("RX at %u.%09u\n", rxTime.tv_sec, rxTime.tv_nsec);
	printf("String: %s\n\n", rxData.string);

	close(s);
	exit(0);
}
